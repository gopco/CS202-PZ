package rs.ac.metropolitan.project.web;

/**
 * Weather info
 */
public record WeatherInfo(String temperature) {

}
